fun main() {
    println("Введите число")
    var a = readln()!!.toDouble()
    var rez = 0.toDouble()
    when{
        (a > 7) -> rez = 1 /(a * a - 4)
        else -> rez = -3 * a - 9
    }
    println(rez)
}