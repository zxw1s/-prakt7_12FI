import kotlin.math.abs
fun main() {
    try {
        println("Введите первое число")
        var a = readLine()!!.toInt()
        println("Введите второе число")
        var b = readLine()!!.toInt()
        println("Введите третье число")
        var c = readLine()!!.toInt()
        when {
            (abs(a)>abs(b) && abs(b)>abs(c)) -> println("${a}, ${b}, ${c}")
            (abs(a)>abs(c) && abs(c)>abs(b)) -> println("${a}, ${c}, ${b}")
            (abs(b)>abs(a) && abs(a)>abs(c)) -> println("${b}, ${a}, ${c}")
            (abs(b)>abs(c) && abs(c)>abs(a)) -> println("${b}, ${c}, ${a}")
            (abs(c)>abs(a) && abs(a)>abs(b)) -> println("${c}, ${a}, ${b}")
            (abs(c)>abs(b) && abs(b)>abs(a)) -> println("${c}, ${b}, ${a}")
        }

    } catch (e: Exception) {
        println("Введите верное число")
    }
}