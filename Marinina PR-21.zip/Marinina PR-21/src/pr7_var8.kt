import kotlin.math.pow
import kotlin.math.abs
import kotlin.math.round
fun main() {
    try {

        val x=-2/3.toDouble()
        var z1=5*(x.pow(3))+ 70*(x.pow(2))+14* x
      var  z2=(abs( 5*x+70)*x+14)*x
            println(round(z1))
            println(round(z2))

          }
    catch(e:Exception)
    {
        println("Введите символ")
    }

}