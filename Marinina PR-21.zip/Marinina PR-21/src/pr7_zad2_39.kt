import kotlin.math.sqrt

fun main() {
    try {
        println("Введите число k ")
        var k = readLine()!!.toDouble()
        println("Введите число b ")
        var b = readLine()!!.toDouble()
        println("Введите число c ")
        var c = readLine()!!.toDouble()
        println("Введите число d ")
        var d= readLine()!!.toDouble()
        println("Введите число e ")
        var e = readLine()!!.toDouble()
        var n1=d-k
        var n2=e-b
        var discr = n1*n2-4*c*n2
        if (discr>=0)
        {
            if (!(discr==0.0))
            {
                var x1=(-n1+ sqrt(discr))/2*c
                var y1=c*x1*x1+d*x1+e
                var x2=(-n1- sqrt(discr))/2*c
                var y2=c*x1*x1+d*x1+e
                println("Первая точка $x1, $y1")
                println("Расстояние до начала координат ${sqrt(x1*x1+y1*y1)}")
                println("Вторая точка $x2, $y2")
                println("Расстояние до начала координат ${sqrt(x2*x2+y2*y2)}")
            }
            else
            {
                var x1=-(n1/2*c)
                var y1=c*x1*x1+d*x1+e
                println("Точка $x1, $y1")
                println("Расстояние до начала координат ${sqrt(x1*x1+y1*y1)}")
            }
        }
        else
            println("Нет решения")

    } catch (e: Exception) {
        println("Введите верное число")
    }
}