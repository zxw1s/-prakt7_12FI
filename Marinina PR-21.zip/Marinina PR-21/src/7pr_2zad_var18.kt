fun main() {
    try {
       var a:Int;
        var b:Int;
        var x:Int;
        var y:Int;
        var z:Int;
        do{
            println("Введите ширину отверстия")
            a= readLine()!!.toInt()
            println("Введите длину отверстия")
            b= readLine()!!.toInt()
            println("Введите длину кирпича")
            x= readLine()!!.toInt()
            println("Введите высоту кирпича")
            y= readLine()!!.toInt()
            println("Введите ширину кирпича")
            z= readLine()!!.toInt()

        }while(a<=0||b<=0||x<=0 || y<=0 || z<=0)
        when
        {
            (a>x && b>y) || (a>y && b>z) || (a>z && b>x)->println("Кирпич проходит")
            else->println("Кирпич не проходит")
        }
    }
    catch (e:Exception)
    {
        print("Введите верное число")

    }    }